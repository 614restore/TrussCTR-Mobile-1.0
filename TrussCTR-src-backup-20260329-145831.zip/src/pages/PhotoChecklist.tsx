import React, { useState, useEffect, useRef } from 'react';
import { Camera, ChevronLeft, CheckCircle2, Circle, Image as ImageIcon, X } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { buildStoredDocumentUrl } from '../lib/documentAccess';

const DEFAULT_ITEMS = [
  'Front Elevation',
  'Rear Elevation',
  'Left Elevation',
  'Right Elevation',
  'Roof Surface (General)',
  'Flashing Details',
  'Gutter Condition',
  'Attic/Interior Leaks',
];

interface PhotoItem {
  label: string;
  photos: { id: string; url: string }[];
  uploading: boolean;
}

export default function PhotoChecklist() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const contactId = searchParams.get('contactId');
  const { profile } = useAuth();
  const [contactName, setContactName] = useState<string | null>(null);
  const [items, setItems] = useState<PhotoItem[]>(
    DEFAULT_ITEMS.map((label) => ({ label, photos: [], uploading: false }))
  );
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(t);
  }, [toast]);

  // Load contact name
  useEffect(() => {
    if (!contactId) { setLoading(false); return; }
    (supabase as any)
      .from('contacts')
      .select('first_name, last_name')
      .eq('id', contactId)
      .single()
      .then(({ data }: { data: any }) => {
        if (data) setContactName(`${data.first_name || ''} ${data.last_name || ''}`.trim());
      });
  }, [contactId]);

  // Load existing photos from documents table
  useEffect(() => {
    if (!contactId || !profile?.company_id) { setLoading(false); return; }
    loadPhotos();
  }, [contactId, profile?.company_id]);

  const loadPhotos = async () => {
    if (!contactId || !profile?.company_id) return;
    setLoading(true);
    try {
      const { data, error } = await (supabase as any)
        .from('documents')
        .select('id, name, url')
        .eq('contact_id', contactId)
        .eq('company_id', profile.company_id)
        .eq('type', 'photo')
        .order('created_at', { ascending: true });

      if (error) throw error;

      const docs: { id: string; name: string; url: string }[] = data || [];

      setItems((prev) =>
        prev.map((item) => ({
          ...item,
          photos: docs
            .filter((d) => d.name.toLowerCase().startsWith(item.label.toLowerCase()))
            .map((d) => ({ id: d.id, url: d.url })),
        }))
      );
    } catch (err) {
      console.error('[PhotoChecklist] load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCapture = async (label: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !contactId || !profile?.company_id) return;

    // Reset file input so same file can be re-selected
    e.target.value = '';

    setItems((prev) =>
      prev.map((item) => (item.label === label ? { ...item, uploading: true } : item))
    );

    try {
      const rawExt = (file.name.split('.').pop() || 'jpg').toLowerCase();
      const ext = rawExt === 'heic' || rawExt === 'heif' ? 'jpg' : rawExt;
      const slug = label.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_]/g, '');
      const filePath = `${contactId}/${slug}_${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('documents')
        .getPublicUrl(filePath);

      const finalUrl = buildStoredDocumentUrl(publicUrl, 'documents', filePath);

      const { data: docData, error: insertError } = await (supabase as any)
        .from('documents')
        .insert({
          contact_id: contactId,
          company_id: profile.company_id,
          name: `${label} Photo`,
          type: 'photo',
          url: finalUrl,
          size: file.size,
          uploaded_by: profile.id,
        })
        .select('id')
        .single();

      if (insertError) throw insertError;

      setItems((prev) =>
        prev.map((item) =>
          item.label === label
            ? { ...item, uploading: false, photos: [...item.photos, { id: docData.id, url: finalUrl }] }
            : item
        )
      );
      setToast(`${label} photo saved`);
    } catch (err) {
      console.error('[PhotoChecklist] upload error:', err);
      setToast('Photo upload failed');
      setItems((prev) =>
        prev.map((item) => (item.label === label ? { ...item, uploading: false } : item))
      );
    }
  };

  const removePhoto = async (label: string, docId: string) => {
    try {
      await (supabase as any).from('documents').delete().eq('id', docId);
      setItems((prev) =>
        prev.map((item) =>
          item.label === label
            ? { ...item, photos: item.photos.filter((p) => p.id !== docId) }
            : item
        )
      );
    } catch (err) {
      console.error('[PhotoChecklist] delete error:', err);
    }
  };

  const completedCount = items.filter((i) => i.photos.length > 0).length;
  const totalPhotos = items.reduce((s, i) => s + i.photos.length, 0);

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 p-6 sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-400 active:scale-90 transition-transform">
            <ChevronLeft size={24} />
          </button>
          <div>
            <h1 className="text-xl font-bold text-primary">Photo Checklist</h1>
            {contactName && <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{contactName}</p>}
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Progress card */}
        <div className="card p-5 bg-primary text-white flex items-center justify-between">
          <div>
            <p className="text-xs text-white/60 font-bold uppercase tracking-widest">Progress</p>
            <p className="text-2xl font-bold">{completedCount} / {items.length}</p>
            <p className="text-xs text-white/60 mt-0.5">{totalPhotos} total photo{totalPhotos !== 1 ? 's' : ''}</p>
          </div>
          <div className="h-14 w-14 rounded-full border-4 border-white/10 flex items-center justify-center">
            <span className="text-sm font-bold">{Math.round((completedCount / items.length) * 100)}%</span>
          </div>
        </div>

        {loading ? (
          [1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 bg-white rounded-2xl animate-pulse border border-slate-100" />
          ))
        ) : (
          <div className="space-y-3">
            {items.map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
                className="card p-4 space-y-3"
              >
                {/* Row: check + label + camera */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {item.photos.length > 0 ? (
                      <CheckCircle2 className="text-emerald-500 shrink-0" size={22} />
                    ) : (
                      <Circle className="text-slate-200 shrink-0" size={22} />
                    )}
                    <div>
                      <p className={`text-sm font-bold ${item.photos.length > 0 ? 'text-slate-400' : 'text-primary'}`}>
                        {item.label}
                      </p>
                      {item.photos.length > 0 && (
                        <p className="text-[10px] text-slate-400 font-medium">{item.photos.length} photo{item.photos.length !== 1 ? 's' : ''}</p>
                      )}
                    </div>
                  </div>

                  {/* Hidden file input */}
                  <input
                    ref={(el) => { fileInputRefs.current[item.label] = el; }}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    onChange={(e) => handleCapture(item.label, e)}
                  />
                  <button
                    disabled={item.uploading}
                    onClick={() => fileInputRefs.current[item.label]?.click()}
                    className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 active:scale-90 transition-transform disabled:opacity-40"
                  >
                    {item.uploading ? (
                      <div className="h-4 w-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Camera size={18} />
                    )}
                  </button>
                </div>

                {/* Photo thumbnails */}
                {item.photos.length > 0 && (
                  <div className="flex gap-2 flex-wrap">
                    {item.photos.map((photo) => (
                      <div key={photo.id} className="relative group">
                        <button
                          onClick={() => setPreviewUrl(photo.url)}
                          className="h-14 w-14 rounded-xl overflow-hidden border border-slate-100 active:scale-95 transition-transform"
                        >
                          <img src={photo.url} alt={item.label} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                        </button>
                        <button
                          onClick={() => removePhoto(item.label, photo.id)}
                          className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity active:scale-90"
                        >
                          <X size={10} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Action Bar */}
      <div
        className="fixed inset-x-0 bg-white border-t border-slate-100 p-4 flex gap-3 z-20"
        style={{ bottom: 'calc(4.75rem + env(safe-area-inset-bottom))' }}
      >
        <div className="flex-1 flex flex-col items-center justify-center">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            {completedCount}/{items.length} sections • {totalPhotos} photos
          </p>
        </div>
        <button
          onClick={() => navigate(-1)}
          className="bg-primary text-white px-8 py-4 rounded-2xl text-xs font-bold uppercase tracking-widest active:scale-95 transition-transform flex items-center gap-2"
        >
          <ImageIcon size={16} />
          Done
        </button>
      </div>

      {/* Photo Preview Modal */}
      {previewUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setPreviewUrl(null)}
        >
          <img src={previewUrl} alt="Preview" className="max-h-full max-w-full rounded-2xl object-contain" referrerPolicy="no-referrer" />
          <button
            className="absolute top-6 right-6 h-10 w-10 bg-white/10 rounded-full flex items-center justify-center text-white active:scale-90"
            onClick={() => setPreviewUrl(null)}
          >
            <X size={20} />
          </button>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-24 left-6 right-6 bg-slate-900 text-white p-4 rounded-2xl shadow-2xl z-50 flex items-center gap-3"
        >
          <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
          <p className="text-xs font-bold">{toast}</p>
        </motion.div>
      )}
    </div>
  );
}
