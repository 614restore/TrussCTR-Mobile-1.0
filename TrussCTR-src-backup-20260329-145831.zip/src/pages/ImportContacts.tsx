import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, CheckCircle2, AlertCircle, ChevronDown, FileText, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { CustomerStatus } from '../types/supabase';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type TrussCTRField =
  | 'first_name' | 'last_name' | 'email' | 'phone1' | 'phone2'
  | 'address' | 'city' | 'state' | 'zip'
  | 'status' | 'lead_source' | 'tags'
  | 'project_type' | 'project_value'
  | 'insurance_company' | 'policy_number' | 'claim_number'
  | 'adjuster_name' | 'adjuster_phone' | 'adjuster_email'
  | '__skip__';

const FIELD_LABELS: Record<TrussCTRField, string> = {
  first_name: 'First Name',
  last_name: 'Last Name',
  email: 'Email',
  phone1: 'Phone 1',
  phone2: 'Phone 2',
  address: 'Address',
  city: 'City',
  state: 'State',
  zip: 'Zip',
  status: 'Status',
  lead_source: 'Lead Source',
  tags: 'Tags',
  project_type: 'Project Type',
  project_value: 'Project Value',
  insurance_company: 'Insurance Company',
  policy_number: 'Policy Number',
  claim_number: 'Claim Number',
  adjuster_name: 'Adjuster Name',
  adjuster_phone: 'Adjuster Phone',
  adjuster_email: 'Adjuster Email',
  __skip__: '— Skip this column —',
};

// ---------------------------------------------------------------------------
// CRM auto-detection patterns
// Key: normalized header → TrussCTR field
// ---------------------------------------------------------------------------

const COLUMN_MAP: Record<string, TrussCTRField> = {
  // Generic / shared
  'first name': 'first_name',
  'firstname': 'first_name',
  'last name': 'last_name',
  'lastname': 'last_name',
  'email': 'email',
  'email address': 'email',
  'phone': 'phone1',
  'phone number': 'phone1',
  'mobile': 'phone1',
  'mobile phone': 'phone1',
  'cell phone': 'phone1',
  'primary phone': 'phone1',
  'secondary phone': 'phone2',
  'address': 'address',
  'address 1': 'address',
  'address line 1': 'address',
  'street address': 'address',
  'street': 'address',
  'city': 'city',
  'state': 'state',
  'zip': 'zip',
  'zip code': 'zip',
  'postal code': 'zip',
  'lead source': 'lead_source',
  'source': 'lead_source',
  'tags': 'tags',
  'project type': 'project_type',
  'project value': 'project_value',
  'contract amount': 'project_value',
  'insurance company': 'insurance_company',
  'insurance carrier': 'insurance_company',
  'carrier': 'insurance_company',
  'policy number': 'policy_number',
  'policy #': 'policy_number',
  'policy no': 'policy_number',
  'claim number': 'claim_number',
  'claim #': 'claim_number',
  'claim no': 'claim_number',
  'adjuster name': 'adjuster_name',
  'adjuster': 'adjuster_name',
  'adjuster phone': 'adjuster_phone',
  'adjuster email': 'adjuster_email',

  // JobNimbus
  'display name': '__skip__',
  'status name': 'status',
  'assigned to': '__skip__',
  'assigned to rep': '__skip__',
  'work type': 'project_type',

  // AccuLynx
  'customer first name': 'first_name',
  'customer last name': 'last_name',
  'customer email': 'email',
  'customer phone': 'phone1',
  'job status': 'status',
  'lead status': 'status',
  'assigned salesperson': '__skip__',

  // Roofr
  'contact name': '__skip__',  // handled specially as full name
  'full name': '__skip__',     // handled specially as full name
  'name': '__skip__',          // handled specially as full name

  // Hail Strike
  'pipeline stage': 'status',

  // JobProgress / improveit360
  'customer status': 'status',
};

// Columns that represent a full "First Last" name — split on first space
const FULL_NAME_COLS = new Set(['contact name', 'full name', 'name', 'display name', 'customer name']);

// ---------------------------------------------------------------------------
// Status normalization — maps CRM status strings → TrussCTR CustomerStatus
// ---------------------------------------------------------------------------

function normalizeStatus(raw: string): CustomerStatus {
  const v = raw.toLowerCase().trim();
  if (v.includes('new') || v.includes('lead')) return 'new_lead';
  if (v.includes('contact')) return 'contacted';
  if (v.includes('appt') || v.includes('appointment')) return 'appointment_set';
  if (v.includes('inspect')) return 'inspected';
  if (v.includes('estimat') || v.includes('quote')) return 'estimate_sent';
  if (v.includes('sign') || v.includes('won') || v.includes('sold')) return 'signed_won';
  if (v.includes('approv')) return 'approved';
  if (v.includes('scheduled') || v.includes('schedule')) return 'scheduled';
  if (v.includes('progress') || v.includes('active') || v.includes('install')) return 'in_progress';
  if (v.includes('complet') || v.includes('done') || v.includes('finish')) return 'completed';
  if (v.includes('paid') || v.includes('closed')) return 'paid';
  if (v.includes('lost') || v.includes('cancel') || v.includes('dead')) return 'lost';
  if (v.includes('retail')) return 'retail';
  return 'new_lead';
}

// ---------------------------------------------------------------------------
// CSV parser — handles quoted fields, CRLF, escaped quotes
// ---------------------------------------------------------------------------

function parseCSV(text: string): string[][] {
  const rows: string[][] = [];
  let col = 0, row = 0, field = '', inQuotes = false;
  rows.push([]);

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (inQuotes) {
      if (ch === '"' && next === '"') { field += '"'; i++; }
      else if (ch === '"') { inQuotes = false; }
      else { field += ch; }
    } else {
      if (ch === '"') { inQuotes = true; }
      else if (ch === ',') {
        rows[row][col] = field; field = ''; col++;
      } else if (ch === '\n' || (ch === '\r' && next === '\n')) {
        rows[row][col] = field; field = ''; col = 0; row++;
        rows.push([]);
        if (ch === '\r') i++;
      } else if (ch === '\r') {
        rows[row][col] = field; field = ''; col = 0; row++;
        rows.push([]);
      } else {
        field += ch;
      }
    }
  }
  // last field
  if (field || rows[row].length > 0) rows[row][col] = field;
  return rows.filter(r => r.some(c => c.trim() !== ''));
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

type ImportStep = 'upload' | 'map' | 'preview' | 'importing' | 'done';

export default function ImportContacts() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<ImportStep>('upload');
  const [crmName, setCrmName] = useState<string>('');
  const [headers, setHeaders] = useState<string[]>([]);
  const [rows, setRows] = useState<string[][]>([]);
  const [mapping, setMapping] = useState<Record<string, TrussCTRField>>({});
  const [importedCount, setImportedCount] = useState(0);
  const [skippedCount, setSkippedCount] = useState(0);
  const [errors, setErrors] = useState<string[]>([]);
  const [dragOver, setDragOver] = useState(false);

  // -------------------------------------------------------------------------
  // Detect CRM source from headers
  // -------------------------------------------------------------------------

  function detectCRM(hdrs: string[]): string {
    const norm = hdrs.map(h => h.toLowerCase().trim());
    if (norm.some(h => h === 'status name' || h === 'display name')) return 'JobNimbus';
    if (norm.some(h => h.includes('customer first name') || h === 'assigned salesperson')) return 'AccuLynx';
    if (norm.some(h => h === 'contact name' || h === 'phone number')) return 'Roofr';
    if (norm.some(h => h === 'pipeline stage')) return 'Hail Strike';
    if (norm.some(h => h === 'customer status')) return 'JobProgress / improveit360';
    return 'Generic CRM';
  }

  // -------------------------------------------------------------------------
  // Build initial mapping from headers
  // -------------------------------------------------------------------------

  function buildMapping(hdrs: string[]): Record<string, TrussCTRField> {
    const m: Record<string, TrussCTRField> = {};
    for (const h of hdrs) {
      const key = h.toLowerCase().trim();
      m[h] = COLUMN_MAP[key] ?? '__skip__';
    }
    return m;
  }

  // -------------------------------------------------------------------------
  // File handling
  // -------------------------------------------------------------------------

  function handleFile(file: File) {
    if (!file) return;
    const name = file.name.toLowerCase();
    if (!name.endsWith('.csv') && !name.endsWith('.txt')) {
      alert('Please export your data as a CSV file (.csv) from your CRM and try again.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const allRows = parseCSV(text);
      if (allRows.length < 2) {
        alert('The file appears to be empty or has only one row.');
        return;
      }
      const hdrs = allRows[0].map(h => h.trim());
      const dataRows = allRows.slice(1);
      const detected = detectCRM(hdrs);
      const initialMap = buildMapping(hdrs);

      setHeaders(hdrs);
      setRows(dataRows);
      setCrmName(detected);
      setMapping(initialMap);
      setStep('map');
    };
    reader.readAsText(file);
  }

  // -------------------------------------------------------------------------
  // Import logic
  // -------------------------------------------------------------------------

  async function runImport() {
    if (!profile?.company_id) return;
    setStep('importing');
    setImportedCount(0);
    setSkippedCount(0);
    setErrors([]);

    // Find which header is the full-name column (if any)
    const fullNameHeader = headers.find(h => FULL_NAME_COLS.has(h.toLowerCase().trim()) && mapping[h] === '__skip__');

    const db = supabase as any;
    const BATCH = 50;
    let imported = 0, skipped = 0;
    const errs: string[] = [];

    for (let i = 0; i < rows.length; i += BATCH) {
      const batch = rows.slice(i, i + BATCH);
      const records = batch.map((row, bIdx) => {
        const rec: Record<string, any> = { company_id: profile.company_id, status: 'new_lead' as CustomerStatus };

        headers.forEach((h, hIdx) => {
          const field = mapping[h];
          const val = (row[hIdx] ?? '').trim();
          if (!val) return;

          if (field === '__skip__') {
            // Check if this is a full-name column we should split
            if (h === fullNameHeader) {
              const spaceIdx = val.indexOf(' ');
              if (spaceIdx > -1) {
                rec.first_name = val.slice(0, spaceIdx).trim();
                rec.last_name = val.slice(spaceIdx + 1).trim();
              } else {
                rec.first_name = val;
              }
            }
            return;
          }

          if (field === 'status') {
            rec.status = normalizeStatus(val);
          } else if (field === 'project_value') {
            const num = parseFloat(val.replace(/[$,]/g, ''));
            if (!isNaN(num)) rec.project_value = num;
          } else if (field === 'tags') {
            rec.tags = val.split(/[,;|]/).map((t: string) => t.trim()).filter(Boolean);
          } else {
            rec[field] = val;
          }
        });

        // Must have at least a first name or last name
        if (!rec.first_name && !rec.last_name) {
          skipped++;
          errs.push(`Row ${i + bIdx + 2}: no name found — skipped`);
          return null;
        }
        rec.first_name = rec.first_name || '';
        rec.last_name = rec.last_name || '';

        return rec;
      }).filter(Boolean);

      if (records.length === 0) continue;

      const { error } = await db.from('contacts').insert(records);
      if (error) {
        errs.push(`Batch ${Math.floor(i / BATCH) + 1} error: ${error.message}`);
        skipped += records.length;
      } else {
        imported += records.length;
      }

      setImportedCount(imported);
      setSkippedCount(skipped);
    }

    setErrors(errs.slice(0, 10));
    setStep('done');
  }

  // -------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 px-4 pt-14 pb-4 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-400 active:scale-90 transition-transform">
          <ArrowLeft size={22} />
        </button>
        <div>
          <h1 className="text-lg font-bold text-primary">Import Contacts</h1>
          <p className="text-xs text-slate-400">From JobNimbus, AccuLynx, Roofr & more</p>
        </div>
      </div>

      <div className="p-6 space-y-6 max-w-lg mx-auto">

        {/* ------------------------------------------------------------------ */}
        {/* STEP 1 — Upload                                                     */}
        {/* ------------------------------------------------------------------ */}
        {step === 'upload' && (
          <>
            {/* Drop zone */}
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={e => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-10 flex flex-col items-center gap-4 cursor-pointer transition-all ${
                dragOver ? 'border-accent bg-accent/5' : 'border-slate-200 bg-white active:bg-slate-50'
              }`}
            >
              <div className="h-16 w-16 rounded-2xl bg-accent/10 flex items-center justify-center">
                <Upload size={28} className="text-accent" />
              </div>
              <div className="text-center">
                <p className="font-bold text-primary">Tap to select your CSV file</p>
                <p className="text-xs text-slate-400 mt-1">or drag and drop here</p>
              </div>
              <input ref={fileInputRef} type="file" accept=".csv,.txt" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
            </div>

            {/* CRM instructions */}
            <div className="space-y-3">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">How to export from your CRM</p>
              {[
                { name: 'JobNimbus', steps: 'Contacts → Export → Export to CSV' },
                { name: 'AccuLynx', steps: 'Customers → Export → Download CSV' },
                { name: 'Roofr', steps: 'Contacts → ··· → Export Contacts → CSV' },
                { name: 'Hail Strike', steps: 'People → Export → CSV Download' },
                { name: 'JobProgress', steps: 'Customers → Export Customers → CSV' },
                { name: 'Other CRM', steps: 'Export contacts/customers as CSV and upload' },
              ].map(crm => (
                <div key={crm.name} className="bg-white rounded-2xl p-4 flex items-start gap-3 border border-slate-100">
                  <FileText size={16} className="text-accent shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-primary">{crm.name}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{crm.steps}</p>
                  </div>
                </div>
              ))}
            </div>

            <p className="text-xs text-slate-400 text-center">
              Excel files (.xlsx) must be saved as CSV first: <br />
              <span className="font-bold">File → Save As → CSV (Comma delimited)</span>
            </p>
          </>
        )}

        {/* ------------------------------------------------------------------ */}
        {/* STEP 2 — Column Mapping                                             */}
        {/* ------------------------------------------------------------------ */}
        {step === 'map' && (
          <>
            <div className="bg-accent/10 rounded-2xl p-4 flex items-center gap-3">
              <CheckCircle2 size={18} className="text-accent shrink-0" />
              <div>
                <p className="text-sm font-bold text-primary">Detected: {crmName}</p>
                <p className="text-xs text-slate-500">{rows.length} contacts found — review column mapping below</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Column Mapping</p>
              {headers.map(h => (
                <div key={h} className="bg-white rounded-2xl p-4 flex items-center gap-3 border border-slate-100">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-600 truncate">{h}</p>
                    <p className="text-[10px] text-slate-400 truncate">
                      e.g. {rows[0]?.[headers.indexOf(h)] || '—'}
                    </p>
                  </div>
                  <div className="relative shrink-0">
                    <select
                      value={mapping[h]}
                      onChange={e => setMapping(prev => ({ ...prev, [h]: e.target.value as TrussCTRField }))}
                      className="appearance-none bg-slate-100 rounded-xl pl-3 pr-8 py-2 text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-accent/30"
                    >
                      {(Object.keys(FIELD_LABELS) as TrussCTRField[]).map(f => (
                        <option key={f} value={f}>{FIELD_LABELS[f]}</option>
                      ))}
                    </select>
                    <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setStep('preview')}
              className="w-full bg-accent text-white py-4 rounded-2xl font-bold text-sm active:scale-95 transition-transform"
            >
              Preview Import →
            </button>
          </>
        )}

        {/* ------------------------------------------------------------------ */}
        {/* STEP 3 — Preview                                                    */}
        {/* ------------------------------------------------------------------ */}
        {step === 'preview' && (
          <>
            <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
              <div className="p-4 border-b border-slate-100">
                <p className="text-sm font-bold text-primary">Preview (first 5 rows)</p>
                <p className="text-xs text-slate-400">{rows.length} total contacts will be imported</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-slate-100">
                      {headers.filter(h => mapping[h] !== '__skip__').map(h => (
                        <th key={h} className="px-3 py-2 text-left font-bold text-slate-400 whitespace-nowrap">
                          {FIELD_LABELS[mapping[h]]}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.slice(0, 5).map((row, ri) => (
                      <tr key={ri} className="border-b border-slate-50">
                        {headers.filter(h => mapping[h] !== '__skip__').map(h => (
                          <td key={h} className="px-3 py-2 text-slate-600 whitespace-nowrap max-w-[120px] truncate">
                            {row[headers.indexOf(h)] || '—'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep('map')}
                className="flex-1 bg-slate-100 text-slate-700 py-4 rounded-2xl font-bold text-sm active:scale-95 transition-transform"
              >
                ← Edit Mapping
              </button>
              <button
                onClick={runImport}
                className="flex-1 bg-accent text-white py-4 rounded-2xl font-bold text-sm active:scale-95 transition-transform"
              >
                Import {rows.length} Contacts
              </button>
            </div>
          </>
        )}

        {/* ------------------------------------------------------------------ */}
        {/* STEP 4 — Importing                                                  */}
        {/* ------------------------------------------------------------------ */}
        {step === 'importing' && (
          <div className="flex flex-col items-center gap-6 py-12">
            <div className="h-20 w-20 rounded-3xl bg-accent/10 flex items-center justify-center">
              <div className="h-10 w-10 border-4 border-accent border-t-transparent rounded-full animate-spin" />
            </div>
            <div className="text-center">
              <p className="font-bold text-primary text-lg">Importing contacts…</p>
              <p className="text-slate-400 text-sm mt-1">{importedCount} imported so far</p>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------------ */}
        {/* STEP 5 — Done                                                       */}
        {/* ------------------------------------------------------------------ */}
        {step === 'done' && (
          <>
            <div className="flex flex-col items-center gap-4 py-8 text-center">
              <div className="h-20 w-20 rounded-3xl bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 size={36} className="text-emerald-500" />
              </div>
              <div>
                <p className="font-bold text-primary text-xl">Import Complete</p>
                <p className="text-slate-400 text-sm mt-1">
                  {importedCount} contacts imported{skippedCount > 0 ? `, ${skippedCount} skipped` : ''}
                </p>
              </div>
            </div>

            {errors.length > 0 && (
              <div className="bg-red-50 rounded-2xl p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <AlertCircle size={16} className="text-red-400 shrink-0" />
                  <p className="text-xs font-bold text-red-600">Some rows had issues</p>
                </div>
                {errors.map((e, i) => (
                  <p key={i} className="text-xs text-red-400 pl-6">{e}</p>
                ))}
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => { setStep('upload'); setHeaders([]); setRows([]); setMapping({}); }}
                className="flex-1 bg-slate-100 text-slate-700 py-4 rounded-2xl font-bold text-sm active:scale-95 transition-transform"
              >
                Import Another
              </button>
              <button
                onClick={() => navigate('/contacts')}
                className="flex-1 bg-accent text-white py-4 rounded-2xl font-bold text-sm active:scale-95 transition-transform"
              >
                View Contacts →
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
