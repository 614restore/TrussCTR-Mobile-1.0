import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Mail, Lock, User, Building2, AlertCircle, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import trussLogo from '../assets/trussctr-logo.png';

type Step = 'form' | 'check-email' | 'setup';

export default function Signup() {
  const navigate = useNavigate();

  const [step, setStep] = useState<Step>('form');
  const [companyName, setCompanyName] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!companyName.trim()) { setError('Please enter your company name.'); return; }
    if (password.length < 8) { setError('Password must be at least 8 characters.'); return; }

    setLoading(true);
    try {
      // 1. Create the auth user
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            first_name: firstName.trim(),
            last_name: lastName.trim(),
            company_name: companyName.trim(),
          },
        },
      });
      if (signUpError) throw signUpError;

      // 2. If session is returned immediately (email confirmation disabled),
      //    create company + profile records right away.
      if (data.session && data.user) {
        await createCompanyAndProfile(data.user.id);
        // AuthContext will pick up the session and redirect to dashboard
        return;
      }

      // 3. Email confirmation required — show check-email screen
      setStep('check-email');
    } catch (err: any) {
      const msg: string = err?.message || '';
      if (msg.toLowerCase().includes('already registered') || msg.toLowerCase().includes('already exists')) {
        setError('An account with that email already exists. Try signing in instead.');
      } else if (msg.toLowerCase().includes('load failed') || msg.toLowerCase().includes('failed to fetch')) {
        setError('Unable to reach the server. Check your internet connection and try again.');
      } else {
        setError(msg || 'Failed to create account. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  async function createCompanyAndProfile(userId: string) {
    const db = supabase as any;

    // Create company
    const { data: company, error: companyErr } = await db
      .from('companies')
      .insert({ name: companyName.trim(), email: email.trim() })
      .select('id')
      .single();

    if (companyErr) {
      // If company creation fails (RLS or other), still create profile without company.
      // The user can set up company later in Settings.
      console.warn('[Signup] company insert failed:', companyErr.message);
    }

    // Create profile
    await db.from('profiles').upsert({
      id: userId,
      email: email.trim(),
      first_name: firstName.trim(),
      last_name: lastName.trim(),
      role: 'owner',
      company_id: company?.id ?? null,
      is_active: true,
    });
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm space-y-8">

        {/* Logo */}
        <div className="text-center space-y-3">
          <div className="mx-auto h-20 w-20 bg-white rounded-[2rem] flex items-center justify-center shadow-xl border border-slate-100 overflow-hidden">
            <img src={trussLogo} alt="TrussCTR" className="h-full w-full object-cover" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-primary">Start your free trial</h1>
            <p className="text-slate-500 text-sm mt-1">14 days free. No credit card required.</p>
          </div>
        </div>

        {/* ── Check email ────────────────────────────────────────────────── */}
        {step === 'check-email' ? (
          <div className="space-y-6">
            <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 flex flex-col items-center gap-3 text-center">
              <CheckCircle size={36} className="text-emerald-500" />
              <div>
                <p className="font-bold text-emerald-800">Check your inbox!</p>
                <p className="text-sm text-emerald-700 mt-1">
                  We sent a confirmation link to <span className="font-bold">{email}</span>.
                  Click it to activate your account.
                </p>
              </div>
            </div>
            <div className="text-center space-y-3">
              <p className="text-xs text-slate-400">Already confirmed?</p>
              <button
                onClick={() => navigate('/login')}
                className="text-accent font-bold text-sm hover:underline"
              >
                Sign in →
              </button>
            </div>
          </div>

        ) : (
          /* ── Sign-up form ──────────────────────────────────────────────── */
          <form onSubmit={handleSignup} className="space-y-5">
            {error && (
              <div className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl flex items-center gap-3 text-sm">
                <AlertCircle size={18} className="shrink-0" />
                <span className="font-medium">{error}</span>
              </div>
            )}

            {/* Company name */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Company Name</label>
              <div className="relative">
                <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="Apex Roofing & Restoration"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all shadow-sm"
                />
              </div>
            </div>

            {/* Name */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Your Name</label>
              <div className="grid grid-cols-2 gap-3">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input
                    type="text"
                    required
                    placeholder="First"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-9 pr-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all shadow-sm text-sm"
                  />
                </div>
                <input
                  type="text"
                  required
                  placeholder="Last"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all shadow-sm text-sm"
                />
              </div>
            </div>

            {/* Email */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Work Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="email"
                  required
                  placeholder="you@yourcompany.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all shadow-sm"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="password"
                  required
                  minLength={8}
                  placeholder="Min. 8 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all shadow-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-accent hover:bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-accent/20 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>Start Free Trial <ArrowRight size={18} /></>
              )}
            </button>

            <p className="text-center text-[10px] text-slate-400 leading-relaxed">
              By signing up you agree to our{' '}
              <span className="font-bold">Terms of Service</span> and{' '}
              <span className="font-bold">Privacy Policy</span>.
            </p>

            <div className="text-center">
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="text-slate-400 text-xs font-bold uppercase tracking-widest hover:text-slate-600 transition-colors inline-flex items-center gap-1"
              >
                <ArrowLeft size={12} /> Already have an account? Sign in
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
