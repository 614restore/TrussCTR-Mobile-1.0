import React, { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, CloudLightning, Thermometer, Wind, Droplets, Search, RefreshCw, AlertTriangle, Calendar, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  fetchNwsAlerts, fetchCurrentConditions, fetchForecast, fetchWeatherHistory,
  geocodeQuery, weatherIcon, alertSeverityColor,
  type NwsAlert, type CurrentConditions, type DailyForecast, type DailyHistory,
} from '../lib/noaaWeather';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function shortDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

function fmtExpires(iso: string | null) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const diffH = (d.getTime() - now.getTime()) / 3_600_000;
  if (diffH < 1)  return 'Expires soon';
  if (diffH < 24) return `Expires in ${Math.round(diffH)}h`;
  return `Expires ${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
}

// ─── Component ────────────────────────────────────────────────────────────────

type Tab = 'alerts' | 'forecast' | 'history';

export default function WeatherAlerts() {
  const navigate = useNavigate();
  const { profile } = useAuth();

  // Location
  const [locationName, setLocationName] = useState('');
  const [lat, setLat]   = useState<number | null>(null);
  const [lon, setLon]   = useState<number | null>(null);
  const [searchInput, setSearchInput]   = useState('');
  const [searching, setSearching]       = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Data
  const [alerts,      setAlerts]      = useState<NwsAlert[]>([]);
  const [current,     setCurrent]     = useState<CurrentConditions | null>(null);
  const [forecast,    setForecast]    = useState<DailyForecast[]>([]);
  const [history,     setHistory]     = useState<DailyHistory[]>([]);
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // UI
  const [tab, setTab] = useState<Tab>('alerts');
  const [expandedAlertId, setExpandedAlertId] = useState<string | null>(null);

  // ── Auto-resolve location from company profile ────────────────────────────

  useEffect(() => {
    const company = profile?.companies as any;
    const parts = [company?.city, company?.state, company?.zip].filter(Boolean).join(' ');
    if (parts) {
      geocodeQuery(parts).then((geo) => {
        if (geo) {
          setLat(geo.lat);
          setLon(geo.lon);
          setLocationName(geo.name);
        }
      });
    }
  }, [profile?.companies]);

  // ── Fetch all weather data ────────────────────────────────────────────────

  const loadData = useCallback(async (la: number, lo: number) => {
    setLoading(true);
    setError(null);
    try {
      const [alertsData, currentData, forecastData, historyData] = await Promise.all([
        fetchNwsAlerts(la, lo),
        fetchCurrentConditions(la, lo),
        fetchForecast(la, lo),
        fetchWeatherHistory(la, lo, 30),
      ]);
      setAlerts(alertsData);
      setCurrent(currentData);
      setForecast(forecastData);
      setHistory(historyData);
      setLastUpdated(new Date());
    } catch (err: any) {
      setError(err.message ?? 'Failed to load weather data. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (lat !== null && lon !== null) loadData(lat, lon);
  }, [lat, lon, loadData]);

  // ── Manual location search ────────────────────────────────────────────────

  const handleSearch = async () => {
    if (!searchInput.trim()) return;
    setSearching(true);
    setLocationError(null);
    const geo = await geocodeQuery(searchInput.trim());
    setSearching(false);
    if (!geo) {
      setLocationError('Location not found. Try a city name, state, or zip code.');
      return;
    }
    setLat(geo.lat);
    setLon(geo.lon);
    setLocationName(geo.name);
    setSearchInput('');
  };

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-slate-50">

      {/* Header */}
      <div className="bg-white border-b border-slate-100 px-4 pt-14 pb-4 sticky top-0 z-20">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-400 active:scale-90 transition-transform">
            <ArrowLeft size={22} />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold text-primary">Weather & Alerts</h1>
            {locationName && <p className="text-xs text-slate-400 truncate">{locationName}</p>}
          </div>
          {lat !== null && (
            <button
              onClick={() => loadData(lat!, lon!)}
              disabled={loading}
              className="p-2 text-slate-400 active:scale-90 transition-transform disabled:opacity-40"
            >
              <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            </button>
          )}
        </div>

        {/* Location search */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search city, state, or zip…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="w-full bg-slate-100 rounded-xl py-2.5 pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-accent/20"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={searching || !searchInput.trim()}
            className="bg-accent text-white text-xs font-bold px-4 rounded-xl disabled:opacity-40 active:scale-95 transition-all"
          >
            {searching ? '…' : 'Go'}
          </button>
        </div>
        {locationError && <p className="text-xs text-red-400 mt-1 ml-1">{locationError}</p>}
      </div>

      {/* No location yet */}
      {lat === null && !loading && (
        <div className="flex flex-col items-center justify-center py-20 px-8 text-center gap-4">
          <div className="h-16 w-16 rounded-2xl bg-sky-100 flex items-center justify-center text-3xl">⛅</div>
          <div>
            <p className="font-bold text-primary">Enter a location</p>
            <p className="text-xs text-slate-400 mt-1">
              Search above, or add your company city/state in Company Profile to auto-load.
            </p>
          </div>
        </div>
      )}

      {/* Loading skeleton */}
      {loading && (
        <div className="p-6 space-y-4">
          {[1,2,3].map(i => <div key={i} className="h-24 bg-white rounded-2xl animate-pulse border border-slate-100" />)}
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="m-6 bg-red-50 border border-red-100 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle size={18} className="text-red-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-red-700">Failed to load weather</p>
            <p className="text-xs text-red-500 mt-1">{error}</p>
          </div>
        </div>
      )}

      {/* Main content */}
      {!loading && !error && current && (
        <div className="p-6 space-y-6">

          {/* Current conditions card */}
          <div className="bg-gradient-to-br from-primary to-accent rounded-3xl p-5 text-white space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-6xl font-black leading-none">{current.tempF}°</p>
                <p className="text-blue-200 text-sm mt-1">{current.description}</p>
                <p className="text-blue-300 text-xs mt-0.5">Feels like {current.feelsLikeF}°F</p>
              </div>
              <span className="text-5xl">{weatherIcon(current.weatherCode, current.isDay)}</span>
            </div>
            <div className="grid grid-cols-3 gap-3 pt-2 border-t border-white/20">
              <div className="flex items-center gap-1.5">
                <Droplets size={14} className="text-blue-200 shrink-0" />
                <div>
                  <p className="text-[10px] text-blue-300">Humidity</p>
                  <p className="text-sm font-bold">{current.humidity}%</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <Wind size={14} className="text-blue-200 shrink-0" />
                <div>
                  <p className="text-[10px] text-blue-300">Wind</p>
                  <p className="text-sm font-bold">{current.windMph} mph {current.windDir}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <Thermometer size={14} className="text-blue-200 shrink-0" />
                <div>
                  <p className="text-[10px] text-blue-300">Precip</p>
                  <p className="text-sm font-bold">{current.precipInch}"</p>
                </div>
              </div>
            </div>
            {lastUpdated && (
              <p className="text-[10px] text-blue-300 text-right">
                Updated {lastUpdated.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
              </p>
            )}
          </div>

          {/* NWS alert count badge */}
          {alerts.length > 0 && (
            <div
              className="bg-red-50 border border-red-100 rounded-2xl p-4 flex items-center gap-3 cursor-pointer active:bg-red-100 transition-colors"
              onClick={() => setTab('alerts')}
            >
              <div className="h-10 w-10 bg-red-500 rounded-xl flex items-center justify-center shrink-0">
                <CloudLightning size={20} className="text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-red-700">
                  {alerts.length} Active NWS Alert{alerts.length > 1 ? 's' : ''}
                </p>
                <p className="text-xs text-red-400 truncate">{alerts[0]?.event}</p>
              </div>
            </div>
          )}

          {/* Tab bar */}
          <div className="flex bg-slate-100 rounded-2xl p-1 gap-1">
            {(['alerts', 'forecast', 'history'] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                  tab === t ? 'bg-white text-primary shadow-sm' : 'text-slate-400'
                }`}
              >
                {t === 'alerts' ? `Alerts${alerts.length ? ` (${alerts.length})` : ''}` : t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>

          {/* ── ALERTS TAB ──────────────────────────────────────────────── */}
          {tab === 'alerts' && (
            <div className="space-y-3">
              {alerts.length === 0 ? (
                <div className="bg-white rounded-2xl p-8 text-center border border-slate-100">
                  <span className="text-4xl">✅</span>
                  <p className="font-bold text-primary mt-3">No active NWS alerts</p>
                  <p className="text-xs text-slate-400 mt-1">No weather watches, warnings, or advisories for this area.</p>
                </div>
              ) : (
                alerts.map((alert) => (
                  <div key={alert.id} className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                    <button
                      onClick={() => setExpandedAlertId(expandedAlertId === alert.id ? null : alert.id)}
                      className="w-full p-4 flex items-start gap-3 text-left active:bg-slate-50 transition-colors"
                    >
                      <span className={`text-[10px] font-bold px-2 py-1 rounded-full shrink-0 mt-0.5 ${alertSeverityColor(alert.severity)}`}>
                        {alert.severity}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-primary">{alert.event}</p>
                        <p className="text-xs text-slate-500 mt-0.5 truncate">{alert.headline}</p>
                        {alert.expires && (
                          <p className="text-[10px] text-slate-400 mt-1">{fmtExpires(alert.expires)}</p>
                        )}
                      </div>
                    </button>
                    {expandedAlertId === alert.id && (
                      <div className="px-4 pb-4 space-y-3 border-t border-slate-100 pt-3">
                        {alert.areaDesc && (
                          <div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Affected Area</p>
                            <p className="text-xs text-slate-600">{alert.areaDesc}</p>
                          </div>
                        )}
                        <div>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Details</p>
                          <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">{alert.description}</p>
                        </div>
                        {alert.instruction && (
                          <div className="bg-amber-50 rounded-xl p-3">
                            <p className="text-[10px] font-bold text-amber-700 uppercase tracking-wider mb-1">Instructions</p>
                            <p className="text-xs text-amber-700 leading-relaxed">{alert.instruction}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
              <p className="text-[10px] text-slate-400 text-center">
                Alerts from National Weather Service (weather.gov). US locations only.
              </p>
            </div>
          )}

          {/* ── FORECAST TAB ─────────────────────────────────────────────── */}
          {tab === 'forecast' && (
            <div className="space-y-2">
              {forecast.map((day, i) => (
                <div key={day.date} className="bg-white rounded-2xl p-4 flex items-center gap-4 border border-slate-100">
                  <div className="w-12 text-center shrink-0">
                    <p className="text-xs font-bold text-slate-600">
                      {i === 0 ? 'Today' : new Date(day.date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short' })}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {new Date(day.date + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </p>
                  </div>
                  <span className="text-2xl shrink-0">{weatherIcon(day.weatherCode, true)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-500">{day.description}</p>
                    {day.precipInch > 0 && (
                      <p className="text-[10px] text-blue-500 font-bold">🌧 {day.precipInch}" precip</p>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold text-primary">{day.maxTempF}°</p>
                    <p className="text-xs text-slate-400">{day.minTempF}°</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ── HISTORY TAB ──────────────────────────────────────────────── */}
          {tab === 'history' && (
            <div className="space-y-3">
              {/* Summary stats */}
              {history.length > 0 && (() => {
                const totalPrecip = history.reduce((s, d) => s + d.precipInch, 0);
                const rainDays    = history.filter(d => d.precipInch > 0.01).length;
                const avgHigh     = Math.round(history.reduce((s, d) => s + d.maxTempF, 0) / history.length);
                return (
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { label: '30-Day Precip', value: `${totalPrecip.toFixed(1)}"`, icon: '🌧' },
                      { label: 'Rain Days',     value: String(rainDays),             icon: '📅' },
                      { label: 'Avg High',      value: `${avgHigh}°F`,              icon: '🌡️' },
                    ].map(s => (
                      <div key={s.label} className="bg-white rounded-2xl p-3 text-center border border-slate-100">
                        <p className="text-xl">{s.icon}</p>
                        <p className="text-lg font-black text-primary mt-1">{s.value}</p>
                        <p className="text-[10px] text-slate-400">{s.label}</p>
                      </div>
                    ))}
                  </div>
                );
              })()}

              {/* Daily rows */}
              <div className="bg-white rounded-2xl border border-slate-100 divide-y divide-slate-50 overflow-hidden">
                {history.slice(0, 30).map((day) => (
                  <div key={day.date} className="flex items-center px-4 py-3 gap-4">
                    <div className="w-24 shrink-0">
                      <p className="text-xs font-bold text-slate-600">{shortDate(day.date + 'T12:00:00')}</p>
                    </div>
                    <div className="flex-1 relative h-2 bg-slate-100 rounded-full overflow-hidden">
                      {day.precipInch > 0 && (
                        <div
                          className="absolute left-0 top-0 h-full bg-blue-400 rounded-full"
                          style={{ width: `${Math.min(100, (day.precipInch / 2) * 100)}%` }}
                        />
                      )}
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      {day.precipInch > 0 && (
                        <span className="text-[10px] font-bold text-blue-500">{day.precipInch}"</span>
                      )}
                      <span className="text-xs font-bold text-primary">{day.maxTempF}°</span>
                      <span className="text-xs text-slate-400">{day.minTempF}°</span>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-slate-400 text-center">
                Historical data from Open-Meteo archive. Precipitation bar scaled to 2" max.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
