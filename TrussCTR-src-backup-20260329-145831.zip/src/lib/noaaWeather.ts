/**
 * Weather Service — NOAA + Open-Meteo
 *
 * NOAA api.weather.gov  — Active NWS alerts (US, free, no key)
 * Open-Meteo            — Current conditions, 7-day forecast, 30-day history
 *                         (global, free, no key, already used for geocoding)
 *
 * NOAA requires a descriptive User-Agent per their Terms of Service.
 */

const NOAA_BASE  = 'https://api.weather.gov';
const NOAA_UA    = '(TrussCTR Roofing CRM, hello@trussctr.com)';
const OM_BASE    = 'https://api.open-meteo.com/v1';
const OM_ARCHIVE = 'https://archive-api.open-meteo.com/v1';

// ─── Public Types ─────────────────────────────────────────────────────────────

export interface NwsAlert {
  id: string;
  event: string;
  headline: string;
  description: string;
  severity: 'Extreme' | 'Severe' | 'Moderate' | 'Minor' | 'Unknown';
  urgency: string;
  onset: string | null;
  expires: string | null;
  areaDesc: string;
  instruction: string | null;
}

export interface CurrentConditions {
  tempF: number;
  feelsLikeF: number;
  humidity: number;
  precipInch: number;
  windMph: number;
  windDir: string;
  weatherCode: number;
  description: string;
  isDay: boolean;
}

export interface DailyForecast {
  date: string;         // YYYY-MM-DD
  maxTempF: number;
  minTempF: number;
  precipInch: number;
  weatherCode: number;
  description: string;
}

export interface DailyHistory {
  date: string;
  maxTempF: number;
  minTempF: number;
  precipInch: number;
}

// ─── WMO Weather Code → Description ──────────────────────────────────────────

export function describeWeatherCode(code: number): string {
  if (code === 0)               return 'Clear sky';
  if (code === 1)               return 'Mainly clear';
  if (code === 2)               return 'Partly cloudy';
  if (code === 3)               return 'Overcast';
  if (code <= 48)               return 'Fog';
  if (code <= 55)               return 'Drizzle';
  if (code <= 65)               return 'Rain';
  if (code <= 75)               return 'Snow';
  if (code <= 77)               return 'Snow grains';
  if (code <= 82)               return 'Rain showers';
  if (code <= 86)               return 'Snow showers';
  if (code === 95)              return 'Thunderstorm';
  if (code >= 96)               return 'Thunderstorm with hail';
  return 'Unknown';
}

export function weatherIcon(code: number, isDay = true): string {
  if (code === 0)               return isDay ? '☀️' : '🌙';
  if (code <= 2)                return isDay ? '⛅' : '🌤️';
  if (code === 3)               return '☁️';
  if (code <= 48)               return '🌫️';
  if (code <= 55)               return '🌦️';
  if (code <= 65)               return '🌧️';
  if (code <= 75)               return '❄️';
  if (code <= 82)               return '🌦️';
  if (code <= 86)               return '🌨️';
  if (code >= 95)               return '⛈️';
  return '🌡️';
}

function windDegToDir(deg: number): string {
  const dirs = ['N','NE','E','SE','S','SW','W','NW'];
  return dirs[Math.round(deg / 45) % 8];
}

// ─── Severity Badge ───────────────────────────────────────────────────────────

export function alertSeverityColor(severity: string): string {
  switch (severity) {
    case 'Extreme': return 'bg-red-600 text-white';
    case 'Severe':  return 'bg-orange-500 text-white';
    case 'Moderate':return 'bg-amber-400 text-slate-900';
    case 'Minor':   return 'bg-yellow-300 text-slate-900';
    default:        return 'bg-slate-400 text-white';
  }
}

// ─── NOAA Active Alerts ───────────────────────────────────────────────────────

export async function fetchNwsAlerts(lat: number, lon: number): Promise<NwsAlert[]> {
  const res = await fetch(
    `${NOAA_BASE}/alerts/active?point=${lat.toFixed(4)},${lon.toFixed(4)}`,
    { headers: { 'User-Agent': NOAA_UA, Accept: 'application/geo+json' } },
  );
  if (!res.ok) {
    // NOAA 404s outside the US — return empty silently
    if (res.status === 404) return [];
    throw new Error(`NWS alerts error (${res.status})`);
  }
  const json = await res.json();
  return (json.features ?? []).map((f: any) => {
    const p = f.properties ?? {};
    return {
      id:          p.id ?? f.id ?? Math.random().toString(),
      event:       p.event ?? 'Weather Alert',
      headline:    p.headline ?? p.event ?? '',
      description: p.description ?? '',
      severity:    p.severity ?? 'Unknown',
      urgency:     p.urgency ?? 'Unknown',
      onset:       p.onset ?? null,
      expires:     p.expires ?? null,
      areaDesc:    p.areaDesc ?? '',
      instruction: p.instruction ?? null,
    } satisfies NwsAlert;
  });
}

// ─── Current Conditions (Open-Meteo) ─────────────────────────────────────────

export async function fetchCurrentConditions(lat: number, lon: number): Promise<CurrentConditions> {
  const params = new URLSearchParams({
    latitude:  String(lat),
    longitude: String(lon),
    current: [
      'temperature_2m',
      'apparent_temperature',
      'relative_humidity_2m',
      'precipitation',
      'weather_code',
      'wind_speed_10m',
      'wind_direction_10m',
      'is_day',
    ].join(','),
    temperature_unit:   'fahrenheit',
    wind_speed_unit:    'mph',
    precipitation_unit: 'inch',
  });
  const res = await fetch(`${OM_BASE}/forecast?${params}`);
  if (!res.ok) throw new Error(`Open-Meteo current error (${res.status})`);
  const json = await res.json();
  const c = json.current ?? {};
  const code = Number(c.weather_code ?? 0);
  const isDay = Boolean(c.is_day);
  return {
    tempF:       Math.round(c.temperature_2m ?? 0),
    feelsLikeF:  Math.round(c.apparent_temperature ?? 0),
    humidity:    Math.round(c.relative_humidity_2m ?? 0),
    precipInch:  Number((c.precipitation ?? 0).toFixed(2)),
    windMph:     Math.round(c.wind_speed_10m ?? 0),
    windDir:     windDegToDir(Number(c.wind_direction_10m ?? 0)),
    weatherCode: code,
    description: describeWeatherCode(code),
    isDay,
  };
}

// ─── 7-Day Forecast (Open-Meteo) ─────────────────────────────────────────────

export async function fetchForecast(lat: number, lon: number): Promise<DailyForecast[]> {
  const params = new URLSearchParams({
    latitude:  String(lat),
    longitude: String(lon),
    daily: [
      'temperature_2m_max',
      'temperature_2m_min',
      'precipitation_sum',
      'weather_code',
    ].join(','),
    temperature_unit:   'fahrenheit',
    precipitation_unit: 'inch',
    timezone:           'auto',
    forecast_days:      '7',
  });
  const res = await fetch(`${OM_BASE}/forecast?${params}`);
  if (!res.ok) throw new Error(`Open-Meteo forecast error (${res.status})`);
  const json = await res.json();
  const d = json.daily ?? {};
  const dates: string[] = d.time ?? [];
  return dates.map((date, i) => {
    const code = Number(d.weather_code?.[i] ?? 0);
    return {
      date,
      maxTempF:   Math.round(d.temperature_2m_max?.[i] ?? 0),
      minTempF:   Math.round(d.temperature_2m_min?.[i] ?? 0),
      precipInch: Number((d.precipitation_sum?.[i] ?? 0).toFixed(2)),
      weatherCode: code,
      description: describeWeatherCode(code),
    };
  });
}

// ─── 30-Day Weather History (Open-Meteo Archive) ─────────────────────────────

export async function fetchWeatherHistory(lat: number, lon: number, days = 30): Promise<DailyHistory[]> {
  const end   = new Date();
  const start = new Date(end.getTime() - (days - 1) * 86_400_000);
  const fmt   = (d: Date) => d.toISOString().split('T')[0];

  const params = new URLSearchParams({
    latitude:   String(lat),
    longitude:  String(lon),
    start_date: fmt(start),
    end_date:   fmt(end),
    daily: [
      'temperature_2m_max',
      'temperature_2m_min',
      'precipitation_sum',
    ].join(','),
    temperature_unit:   'fahrenheit',
    precipitation_unit: 'inch',
    timezone:           'auto',
  });
  const res = await fetch(`${OM_ARCHIVE}/archive?${params}`);
  if (!res.ok) throw new Error(`Open-Meteo archive error (${res.status})`);
  const json = await res.json();
  const d = json.daily ?? {};
  const dates: string[] = d.time ?? [];
  return dates.map((date, i) => ({
    date,
    maxTempF:   Math.round(d.temperature_2m_max?.[i] ?? 0),
    minTempF:   Math.round(d.temperature_2m_min?.[i] ?? 0),
    precipInch: Number((d.precipitation_sum?.[i] ?? 0).toFixed(2)),
  })).reverse(); // most recent first
}

// ─── Geocode (uses Open-Meteo, same as hailAlertService) ─────────────────────

export async function geocodeQuery(query: string): Promise<{ lat: number; lon: number; name: string } | null> {
  if (!query.trim()) return null;
  try {
    const res = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=1&language=en&format=json`,
    );
    if (!res.ok) return null;
    const json = await res.json();
    const r = json.results?.[0];
    if (!r) return null;
    return {
      lat:  Number(r.latitude),
      lon:  Number(r.longitude),
      name: `${r.name}${r.admin1 ? `, ${r.admin1}` : ''}`,
    };
  } catch {
    return null;
  }
}
